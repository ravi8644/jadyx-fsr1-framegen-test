# Limite de resolução de saída (`output_cap`)

O limite de saída reduz a resolução do swapchain quando o FSR está usando a resolução informada pela TV. O console continua escalando a imagem para a tela. O padrão é `screen`, que mantém o comportamento atual. O limite não altera o caminho sem FSR.

Configure em `boot.cfg`:

```ini
output_cap=screen
```

Valores aceitos:

| Valor | Efeito |
|---|---|
| `screen` | Sem limite; usa a resolução da tela. É o padrão. |
| `1440p` | Limita a altura a 1440 linhas sempre que o FSR usa a resolução da tela. |
| `1080p` | Limita a altura a 1080 linhas nas mesmas condições. |
| `auto` | Limita a 1440p apenas quando FSR e geração de quadros estão ativos juntos. |

O cálculo preserva a proporção, usa largura par e nunca amplia uma imagem menor que o limite. A mesma regra é aplicada na inicialização e ao redimensionar pelo menu durante o jogo.

A estimativa para 12 imagens de tela de 32 bits é de aproximadamente 380 MiB em 4K, 169 MiB em 1440p e 95 MiB em 1080p. São estimativas de buffers, não uma medição do uso total de RAM; o ganho real varia por jogo e configuração. Resoluções menores podem deixar a imagem mais suave após a escala para 4K.

O teste `tools/xbox/tests/output-cap.cpp` valida o parse, os limites 4K/1440p/1080p, o modo automático com e sem Frame Generation, proporções ultrawide, entradas extremas e uma varredura de dimensões.

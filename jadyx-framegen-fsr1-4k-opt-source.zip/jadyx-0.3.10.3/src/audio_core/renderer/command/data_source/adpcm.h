// SPDX-FileCopyrightText: Copyright 2022 yuzu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include <array>
#include <string>

#include "audio_core/common/common.h"
#include "audio_core/common/wave_buffer.h"
#include "audio_core/renderer/command/icommand.h"
#include "common/common_types.h"

namespace AudioCore::ADSP::AudioRenderer {
class CommandListProcessor;
}

namespace AudioCore::Renderer {

/**
 * AudioRenderer command to decode ADPCM-encoded version 1 wavebuffers
 * into the output_index mix buffer.
 */
struct AdpcmDataSourceVersion1Command : ICommand {
    /**
     * Print this command's information to a string.
     *
     * @param processor - The CommandListProcessor processing this command.
     * @param string    - The string to print into.
     */
    void Dump(const AudioRenderer::CommandListProcessor& processor, std::string& string) override;

    /**
     * Process this command.
     *
     * @param processor - The CommandListProcessor processing this command.
     */
    void Process(const AudioRenderer::CommandListProcessor& processor) override;

    /**
     * Verify this command's data is valid.
     *
     * @param processor - The CommandListProcessor processing this command.
     * @return True if the command is valid, otherwise false.
     */
    bool Verify(const AudioRenderer::CommandListProcessor& processor) override;

    /// Quality used for sample rate conversion
    SrcQuality src_quality;
    /// Mix buffer index for decoded samples
    s16 output_index;
    /// Flags to control decoding (see AudioCore::Renderer::VoiceInfo::Flags)
    u16 flags;
    /// Wavebuffer sample rate
    u32 sample_rate;
    /// Pitch used for sample rate conversion
    f32 pitch;
    /// Wavebuffers containing the wavebuffer address, context address, looping information etc
    std::array<WaveBufferVersion2, MaxWaveBuffers> wave_buffers;
    /// Voice state, updated each call and written back to game
    CpuAddr voice_state;
    /// Coefficients data address
    CpuAddr data_address;
    /// Coefficients data size
    u64 data_size;
};

/**
 * AudioRenderer command to decode ADPCM-encoded version 2 wavebuffers
 * into the output_index mix buffer.
 */
struct AdpcmDataSourceVersion2Command : ICommand {
    /**
     * Print this command's information to a string.
     *
     * @param processor - The CommandListProcessor processing this command.
     * @param string    - The string to print into.
     */
    void Dump(const AudioRenderer::CommandListProcessor& processor, std::string& string) override;

    /**
     * Process this command.
     *
     * @param processor - The CommandListProcessor processing this command.
     */
    void Process(const AudioRenderer::CommandListProcessor& processor) override;

    /**
     * Verify this command's data is valid.
     *
     * @param processor - The CommandListProcessor processing this command.
     * @return True if the command is valid, otherwise false.
     */
    bool Verify(const AudioRenderer::CommandListProcessor& processor) override;

    /// Quality used for sample rate conversion
    SrcQuality src_quality;
    /// Mix buffer index for decoded samples
    s16 output_index;
    /// Flags to control decoding (see AudioCore::Renderer::VoiceInfo::Flags)
    u16 flags;
    /// Wavebuffer sample rate
    u32 sample_rate;
    /// Pitch used for sample rate conversion
    f32 pitch;
    /// Target channel to read within the wavebuffer
    s8 channel_index;
    /// Number of channels within the wavebuffer
    s8 channel_count;
    /// Wavebuffers containing the wavebuffer address, context address, looping information etc
    std::array<WaveBufferVersion2, MaxWaveBuffers> wave_buffers;
    /// Voice state, updated each call and written back to game
    CpuAddr voice_state;
    /// Coefficients data address
    CpuAddr data_address;
    /// Coefficients data size
    u64 data_size;
};

} // namespace AudioCore::Renderer
